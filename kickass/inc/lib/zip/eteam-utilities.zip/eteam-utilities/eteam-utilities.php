<?php
/*
Plugin Name: Eteam Utilities
Plugin URI: http://www.eteam.dk/
Description: Extra site functionalities like widgets, shortcodes and many more.
Author: Eteam.dk
Author URI: http://www.eteam.dk/
Text Domain: eteam-utilities
Version: 1.0.0
License: GPL2+
*/

if( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if( ! class_exists('eteam_utilities') ) :


class eteam_utilities {


	/*
	*  __construct
	*
	*  A dummy constructor to ensure Eteam Utilities is only initialized once
	*
	*  @type	function
	*  @date	04/17/17
	*  @since	1.0.0
	*
	*  @param	N/A
	*  @return	N/A
	*/

	function __construct() {

		/* Do nothing here */

	}


	/*
	*  initialize
	*
	*  The real constructor to initialize Eteam Utilities
	*
	*  @type	function
	*  @date	04/17/17
	*  @since	1.0.0
	*
	*  @param	N/A
	*  @return	N/A
	*/

	function initialize() {

		// vars
		$this->settings = array(

			// basic
			'name'				=> __( 'Eteam Utilities', 'eteam-utilities' ),
			'version'			=> '1.0.0'

		);

		// actions
		add_action( 'init',	array($this, 'eteam_register_bootstrap') ); // load Eteam framework resources

		// added image thumbnail
		add_image_size( 'billederi-thumbnail', 230, 155, true );

		// includes
		include( 'lib/widgets.php' ); 		// widgets
		include( 'lib/shortcodes.php' ); 	// shortcode

	}


	/*
	*  eteam_register_bootstrap
	*
	*  @type	function
	*  @date	04/17/17
	*  @since	1.0.0
	*/

	function eteam_register_bootstrap() {

		// -- scripts -- //
		wp_register_script( 'slick', plugin_dir_url( __FILE__ ) . 'assets/js/slick.js', array( 'jquery' ), $this->settings['version'] );
		wp_register_script( 'eteam-utilities-scripts', plugin_dir_url( __FILE__ ) . 'assets/js/eteam-utilities-scripts.js', array( 'jquery' ), $this->settings['version'] );

		/*register*/
		wp_enqueue_script( 'slick' );
		wp_enqueue_script( 'eteam-utilities-scripts' );

		// -- styles -- //
		wp_register_style( 'eteam-utilities-bootstrap', plugin_dir_url( __FILE__ ) . 'assets/css/bootstrap.css', array(), $this->settings['version'] );
		wp_register_style( 'slick', plugin_dir_url( __FILE__ ) . 'assets/css/slick.css', array(), $this->settings['version'] );

		/*register*/
		wp_enqueue_style( 'slick' );
		wp_enqueue_style( 'eteam-utilities-bootstrap' );

	}


}


/*
*  eteam_utilities
*
*  The main function responsible for returning the one true eteam_utilities Instance to functions everywhere.
*  Use this function like you would a global variable, except without needing to declare the global.
*
*  Example: <?php $eteam_utilities = eteam_utilities(); ?>
*
*  @type	function
*  @date	04/17/17
*  @since	1.0.0
*
*  @param	N/A
*  @return	(object)
*/

function eteam_utilities() {

	global $eteam_utilities;

	if( !isset($eteam_utilities) ) {

		$eteam_utilities = new eteam_utilities();

		$eteam_utilities->initialize();

	}

	return $eteam_utilities;

}


// initialize
eteam_utilities();


endif; // class_exists check