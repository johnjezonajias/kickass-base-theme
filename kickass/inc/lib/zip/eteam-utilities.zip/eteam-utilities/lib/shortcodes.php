<?php
/**
 * Produkt Carousel
 * @since  1.0.0
 */
function produkter_carousel( $atts ) {

    // attributes
    $a = shortcode_atts( array(
        'show' => '6',
        'speed' => '0',
        'style' => '',
        'size' => ''
    ), $atts );

    $content = '<div class="produkt-carousel ' . $a['style']. ' ' . $a['size']. '">';
      $content .= '<div class="produkt-carousel-inner">';

    // Arguments
    $args = array( 'post_type' => 'produkt',
                   'orderby' => 'menu_order',
                   'posts_per_page' => -1,
                   'post_parent' => 0,
                   'order' => 'ASC',
                   'post_status' => 'publish' );

    // The Query
    $produkter_query = new WP_Query( $args );
    $stopper = 1;

    // The Loop
    if ( $produkter_query->have_posts() ) {
      while ( $produkter_query->have_posts() ) {
        $produkter_query->the_post();
        $content .= '<div class="produkt-box">
                      <a href="' . get_the_permalink() . '">
                        <img src="' . get_field('featured_thumbnail') . '" />
                        <div class="figcaption">
                        	<div class="figcaption-inner">' . get_the_title() . '</div>
                        </div>
                      </a>
                    </div>';
      }
      wp_reset_postdata();
    }

      $content .= '</div>';
    $content .= '</div>';

    return $content;
}
add_shortcode( 'produkter_carousel', 'produkter_carousel' );

/**
 * Produkt Grid
 * @since  1.0.0
 */
function produkter_grid( $atts ) {

    $content = '<section class="produkt-grid">';
			$content .= '<div class="produkt-grid-inner">';

		// Arguments
		$args = array( 'post_type' => 'produkt',
									 'posts_per_page' => -1,
									 'post_parent' => 0,
									 'orderby' => 'menu_order',
									 'order' => 'ASC',
									 'post_status' => 'publish' );

		// The Query
		$produkter_query = new WP_Query( $args );

		// The Loop
		if ( $produkter_query->have_posts() ) {
			while ( $produkter_query->have_posts() ) {
				$produkter_query->the_post();

				$content .= '<figure class="produkt-grid-box">
											<a href="' . get_the_permalink() . '">
												<img src="' . get_field('featured_thumbnail') . '" />
												<div class="hidden-caption">
													<figcaption>' . get_the_title() . '</figcaption>
													<span>' . get_field('intro_text') . '</span>
												</div>
											</a>
										</figure>';
			}
			wp_reset_postdata();
		}

			$content .= '</div>';
		$content .= '</section>';

    return $content;
}
add_shortcode( 'produkter_grid', 'produkter_grid' );

/**
 * Nyheder List
 * @since  1.0.0
 */
function nyheder_list( $atts ) {

		// attributes
    $a = shortcode_atts( array(
        'posts' => '4',
        'show_more' => false,
        'custom_links' => esc_url( home_url( '/nyheder/' ) )
    ), $atts );

    $content = '<ul class="nyheder-list">';

		// Arguments
		$args = array( 'post_type' => 'nyheder',
									 'orderby' => 'date',
									 'post_status' => 'publish',
									 'posts_per_page' => $a['posts'] );

		// The Query
		$nyheder_query = new WP_Query( $args );

		// The Loop
		if ( $nyheder_query->have_posts() ) {
			while ( $nyheder_query->have_posts() ) {
				$nyheder_query->the_post();
				$content .= '<li>
											<h5 class="nyheder-list-title"><a href="' . $a['custom_links'] . '">' . get_the_title() . '</a></h5>
											<span class="nyheder-list-excerpt">' . get_field( 'nyheder_excerpt' ) . '</span>
										</li>';
			}
			wp_reset_postdata();
		}

		if( $a['show_more'] == true ) {
				$content .= '<a href="' . get_post_type_archive_link( 'nyheder' ) . '" class="btn-full">' . __( 'Læs flere Nyheder »', 'eteam-utilities' ) . '</a>';
		}

		$content .= '</ul>';

    return $content;
}
add_shortcode( 'nyheder_list', 'nyheder_list' );

/**
 * Gallery CPT
 * @since  1.0.0
 */
function cptui_register_my_cpts_gallery() {

	/**
	 * Post Type: Galleries.
	 */

	$labels = array(
		"name" => __( 'Galleries', '' ),
		"singular_name" => __( 'Gallery', '' ),
	);

	$args = array(
		"label" => __( 'Galleries', '' ),
		"labels" => $labels,
		"description" => "",
		"public" => false,
		"publicly_queryable" => false,
		"show_ui" => true,
		"show_in_rest" => false,
		"rest_base" => "",
		"has_archive" => false,
		"show_in_menu" => true,
		"exclude_from_search" => true,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => false,
		"query_var" => false,
		"menu_icon" => "dashicons-images-alt",
		"supports" => array( "title" ),
	);

	register_post_type( "gallery", $args );
}

add_action( 'init', 'cptui_register_my_cpts_gallery' );

if( function_exists('acf_add_local_field_group') ):

acf_add_local_field_group(array (
	'key' => 'group_5925604e69830',
	'title' => 'Gallery Images',
	'fields' => array (
		array (
			'key' => 'field_592562f9e34d2',
			'label' => 'Images',
			'name' => 'images',
			'type' => 'gallery',
			'instructions' => '',
			'required' => 1,
			'conditional_logic' => 0,
			'wrapper' => array (
				'width' => '',
				'class' => '',
				'id' => '',
			),
			'min' => '',
			'max' => '',
			'insert' => 'append',
			'library' => 'all',
			'min_width' => '',
			'min_height' => '',
			'min_size' => '',
			'max_width' => '',
			'max_height' => '',
			'max_size' => '',
			'mime_types' => '',
		),
	),
	'location' => array (
		array (
			array (
				'param' => 'post_type',
				'operator' => '==',
				'value' => 'gallery',
			),
		),
	),
	'menu_order' => 0,
	'position' => 'normal',
	'style' => 'default',
	'label_placement' => 'top',
	'instruction_placement' => 'label',
	'hide_on_screen' => '',
	'active' => 1,
	'description' => '',
));

endif;

/**
 * Eteam Gallery
 */
function show_eteam_gallery( $atts ) {

		// attributes
    $a = shortcode_atts( array(
        'id' => ''
    ), $atts );

    if( $a['id'] == '' ) {
    	return;
    }

    $content = '<div class="billeder-gallery">';

		// Arguments
		$args = array( 'post_type' => 'gallery',
									 'p' => $a['id'],
									 'posts_per_page' => 1 );

		// The Query
		$gallery_query = new WP_Query( $args );

		// The Loop
		if ( $gallery_query->have_posts() ) {
			while ( $gallery_query->have_posts() ) {
				$gallery_query->the_post();
				$images = get_field('images');
				if( $images ) {
					foreach( $images as $image ){
						$content .= '<a href="'. $image['url'] .'" data-lightbox="'.get_the_title().'">';
							$content .= '<img src="'.$image['sizes']['billederi-thumbnail'].'" />';
						$content .= '</a>';
					}
				}
			}
			wp_reset_postdata();
		}

		$content .= '</div>';

    return $content;
}
add_shortcode( 'show_eteam_gallery', 'show_eteam_gallery' );