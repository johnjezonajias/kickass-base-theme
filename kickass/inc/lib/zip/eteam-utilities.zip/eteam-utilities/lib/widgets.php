<?php
/**
 * Produkt Carousel Widget
 * @since  1.0.0
 */
class Produkt_Carousel_Widget extends WP_Widget {

  // Set up the widget name and description.
  public function __construct() {
    $widget_options = array( 'classname' => 'produkt_carousel_widget', 'description' => 'Widget to show produkt carousel' );
    parent::__construct( 'produkt_carousel_widget', 'Eteam - Produkt Carousel', $widget_options );
  }

  // Create the widget output.
  public function widget( $args, $instance ) {
    switch ( $instance[ 'carousel_type' ] ) {
      case 'mini':
        if( isset($instance[ 'title' ]) ) printf( '<h3 class="produkt-carousel-title">%1$s</h3>', $instance[ 'title' ] );
        echo do_shortcode( '[produkter_carousel style="reverse" size="small"]' );
        break;

      default:
        echo do_shortcode( '[produkter_carousel]' );
        break;
    }
  }

  // Create the admin area widget settings form.
  public function form( $instance ) {
    global $wp_customize;
    $title = isset( $instance['title'] ) ? $instance['title'] : '';
    $carousel_type = isset( $instance['carousel_type'] ) ? $instance['carousel_type'] : ''; ?>
    <p>
      <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'eteam-utilities' ) ?></label>
      <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
    </p>
    <p>
        <label for="<?php echo $this->get_field_id( 'carousel_type' ); ?>"><?php _e( 'Carousel Type:', 'eteam-utilities' ) ?></label>
        <select id="<?php echo $this->get_field_id( 'carousel_type' ); ?>" name="<?php echo $this->get_field_name( 'carousel_type' ); ?>">
          <option <?php if( $carousel_type == 'normal' ) echo 'selected'; ?> value="normal"><?php _e( 'Normal', 'eteam-utilities' ) ?></option>
          <option <?php if( $carousel_type == 'mini' ) echo 'selected'; ?> value="mini"><?php _e( 'Mini', 'eteam-utilities' ) ?></option>
        </select>
    </p><?php
  }

  // Apply settings to the widget instance.
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;
    $instance[ 'title' ] = $new_instance[ 'title' ];
    $instance[ 'carousel_type' ] = $new_instance[ 'carousel_type' ];
    return $instance;
  }
}

// -- Produkt Carousel Widget -- //
function produkt_carousel_register_widget() {
  register_widget( 'Produkt_Carousel_Widget' );
}
add_action( 'widgets_init', 'produkt_carousel_register_widget' );


/**
 * Eteam Gallery Widget
 * @since  1.0.0
 */
class Eteam_Gallery_Widget extends WP_Widget {

  // Set up the widget name and description.
  public function __construct() {
    $widget_options = array( 'classname' => 'gallery_widget', 'description' => 'Widget to show gallery' );
    parent::__construct( 'eteam_gallery_widget', 'Eteam - Gallery', $widget_options );
  }

  // Create the widget output.
  public function widget( $args, $instance ) {
    echo do_shortcode( '[show_eteam_gallery id="'.$instance[ 'gallery_id' ].'"]' );
  }

  // Create the admin area widget settings form.
  public function form( $instance ) {
    global $wp_customize; ?>
    <p>
        <label for="<?php echo $this->get_field_id( 'gallery_id' ); ?>"><?php _e( 'Eteam Gallery:', 'eteam-utilities' ) ?></label>
        <select id="<?php echo $this->get_field_id( 'gallery_id' ); ?>" name="<?php echo $this->get_field_name( 'gallery_id' ); ?>">
          <?php
            // Set content
            $content = '';

            // Arguments
            $args = array( 'post_type' => 'gallery' );

            // The Query
            $eteam_gallery_query = new WP_Query( $args );

            // The Loop
            if ( $eteam_gallery_query->have_posts() ) {
              while ( $eteam_gallery_query->have_posts() ) {
                $eteam_gallery_query->the_post();
                $selected_gallery = ( $instance['gallery_id'] == get_the_ID() ) ? 'selected' : '';
                $content .= '<option value="'.get_the_ID().'" '.$selected_gallery.'>';
                  $content .= get_the_title();
                $content .= '</option>';
              }
              wp_reset_postdata();
            }

            echo $content;
          ?>
        </select>
    </p><?php
  }

  // Apply settings to the widget instance.
  public function update( $new_instance, $old_instance ) {
    $instance = $old_instance;
    $instance[ 'gallery_id' ] = $new_instance[ 'gallery_id' ];
    return $instance;
  }
}

// -- Register Eteam Gallery Widget -- //
function eteam_gallery_register_widget() {
  register_widget( 'Eteam_Gallery_Widget' );
}
add_action( 'widgets_init', 'eteam_gallery_register_widget' );


/**
 * File Upload
 * @since  1.0.0
 */
class skdk_pdf_file_upload extends WP_Widget
{
    /**
     * Constructor
     **/
    public function __construct() {

        $widget_ops = array(
            'classname' => 'skdk_pdf_file_upload',
            'description' => 'Upload PDF and auto list.'
        );

        parent::__construct( 'skdk_pdf_file_upload', 'Eteam - PDF File List', $widget_ops );
    }

    /**
     * Outputs the HTML for this widget.
     *
     * @param array  An array of standard parameters for widgets in this theme
     * @param array  An array of settings for this widget instance
     * @return void Echoes it's output
     **/
    public function widget( $args, $instance ) { ?>

      <div class="pdf-list">
          <h5><?php echo $instance['title']; ?></h5>
          <?php
              global $post;
              $widget_post = new WP_Query( array( 'p' => $post->ID, 'post_type' => 'any' ) );
              if ( $widget_post->have_posts() ) {
                while ( $widget_post->have_posts() ) {
                  $widget_post->the_post();
                  if( have_rows('pdf') ) {
                    echo '<ul>';
                    while ( have_rows('pdf') ) : the_row();
                      $title =  get_sub_field('title');
                      $file =  get_sub_field('file');
                      //print_r( $file );
                      printf( '<li><a href="%2$s" class="skdk-btn pdf-file" title="%1$s" target="_blank"><span>%1$s</span></a></li>', $title, $file['url'] );
                    endwhile;
                    echo '</ul>';
                  }
                }

                /* Restore original Post Data */
                wp_reset_postdata();
              }
          ?>
      </div>
      <?php
    }

    /**
     * Deals with the settings when they are saved by the admin. Here is
     * where any validation should be dealt with.
     *
     * @param array  An array of new settings as submitted by the admin
     * @param array  An array of the previous settings
     * @return array The validated and (if necessary) amended settings
     **/
    public function update( $new_instance, $old_instance ) {

        // update logic goes here
        $updated_instance = $new_instance;
        return $updated_instance;
    }

    /**
     * Displays the form for this widget on the Widgets page of the WP Admin area.
     *
     * @param array  An array of the current settings for this widget
     * @return void
     **/
    public function form( $instance ) {

      $title = isset( $instance['title'] ) ? $instance['title'] : ''; ?>
      <p>
        <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'PDF Title' ) ?></label>
        <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $title ); ?>"/>
      </p>
      <?php
    }
}
function skdk_pdf_file_upload_register_widget() {
  register_widget( 'skdk_pdf_file_upload' );
}
add_action( 'widgets_init', 'skdk_pdf_file_upload_register_widget' );